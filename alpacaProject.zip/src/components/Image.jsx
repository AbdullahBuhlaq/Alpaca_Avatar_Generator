
function Image()
{
    return(
        <img src='' alt='' id="image" />
    )
}

export default Image;