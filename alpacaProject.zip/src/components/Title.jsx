function Title()
{
    return(
        <h1 className="header">ALPACA GENERATOR <small>Dhooh noob</small></h1>
    )
}

export default Title;